export default class Hero {
	constructor(x, y, width, height, xDelta, yDelta) {
		this.x = x;
		this.y = y;
		this.width = width,
		this.height = height;
		this.xDelta = xDelta;
		this.yDelta = yDelta;
	}

	enemiesNumber = 15;
	enemieHeal = [];
	enemies = [];
	bullets = [];
	heroHealth = [];

	heroHealing() {
		this.heroHealth.push({
			x: 80,
			y: 20,
			width: 100,
			height: 50,
		})
	}

	goLeft() {
		this.xDelta = -7;
	}
	goRight() {
		this.xDelta = 7;
	}
	stop() {
		this.xDelta = 0;
	}
	fire() {
		this.bullets.push({
			x: this.x + this.width,
			y: this.y + this.y/4,
			width: 40,
			height: 40,
			xDelta: 15,
		})
	}
	jump() {
		this.yDelta = -18;
	}
}