import Hero from './data.js';
const hero = new Hero(30, 428, 150, 200, 0, 0);
hero.heroHealing();

const canvas = document.querySelector('canvas');
const ctx = canvas.getContext('2d');

const bcImg = document.createElement("img");
bcImg.src = "./img/bcImg.jpg";

const heroImg = document.createElement("img");
heroImg.src = "./img/hero.png";

const bulletImg = document.createElement('img');
bulletImg.src = "./img/star.png";

const enemieImg = document.createElement('img');
enemieImg.src = "./img/zombie.png";

const heartImg = document.createElement('img');
heartImg.src = "./img/hero_heart.png";

function condition() {
	if(hero.x < 0) {
		hero.x = 0;
	}
	if(hero.x + hero.width > canvas.width) {
		hero.x = canvas.width-hero.width;
	}
	if(hero.y<0) {
		hero.y = 0;
		hero.yDelta = 22;
	}
	if(hero.y >= 428) {
		hero.y = 428
	}
	if(hero.enemiesNumber > 0) {
		hero.enemies.push({
			x: canvas.width + Math.random() * 12000,
			y: 428,
			width: 150,
			height: 200,
			xDelta: -3,
		});
		hero.enemies.forEach((enemie) => {
			hero.enemieHeal.push({
				x: enemie.x + 35,
				y: enemie.y -20,
				width: 100,
				height: 10,
				xDelta: enemie.xDelta,
			})
		})
		hero.enemiesNumber--;
	}
}

function update() {
	hero.x += hero.xDelta;
	hero.y += hero.yDelta;

	hero.bullets.forEach((bullet) => {
		bullet.x += bullet.xDelta;
	})

	hero.enemies.forEach((enemie) => {
		enemie.x += enemie.xDelta;
	})

	hero.enemieHeal.forEach((enemieHeal) => {
		enemieHeal.x += enemieHeal.xDelta;
	})
}

function draw() {
	ctx.clearRect(0,0,canvas.width, canvas.height);
	//for Background Image
	ctx.drawImage(bcImg, 0,0, canvas.width, canvas.height);
	//for Hero
	ctx.drawImage(heroImg, hero.x, hero.y, hero.width, hero.height);
	//For Hero Health
	ctx.drawImage(heartImg, 15, 15, 60,60);
	hero.heroHealth.forEach((heroHeal)=>{
		ctx.lineWidth = 1;
		ctx.strokeStyle = "#333";
		ctx.strokeRect(heroHeal.x ,heroHeal.y, heroHeal.width, heroHeal.height);
		ctx.fillStyle = "#E74C3C";
		ctx.fillRect(heroHeal.x ,heroHeal.y, heroHeal.width, heroHeal.height)
	})
	

	//bullets
	hero.bullets.forEach((bullet) => {
		ctx.drawImage(bulletImg, bullet.x, bullet.y, bullet.width, bullet.height);
	});

	//enemies
	hero.enemies.forEach((enemie) => {
		ctx.drawImage(enemieImg, enemie.x, enemie.y, enemie.width, enemie.height);
	});

	//enemies_health
	hero.enemieHeal.forEach((enemieHeal) => {
		ctx.fillStyle = "red";
		ctx.fillRect(enemieHeal.x, enemieHeal.y, enemieHeal.width, enemieHeal.height);

		ctx.strokeStyle = "black";
		ctx.lineWidth = 1;
		ctx.strokeRect(enemieHeal.x, enemieHeal.y, enemieHeal.width, enemieHeal.height);
	})
}

function loop() {
	requestAnimationFrame(loop);
	condition();
	update();
	draw();
}
loop();

document.addEventListener('keydown', (evt) => {
	if(evt.code === "ArrowRight") {
		hero.goRight();
	}
	else if(evt.code === "ArrowLeft") {
		hero.goLeft();
	}
	else if(evt.code === "Space") {
		setInterval(
			hero.fire(),
		1000);
	}
	else if(evt.code === "ArrowUp" && hero.y >= 428) {
		hero.jump();
	}
});

document.addEventListener('keyup', () => {
	hero.stop();
});